#include <stdio.h>

#include "./print_module.h"
// #include "documentation_module.h"

int main() {
    print_log(print_char, "System started successfully!");

    return 0;
}
